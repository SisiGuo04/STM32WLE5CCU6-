#include "task.h"


static uint8_t keyvalue = 255;

uint8_t key_return(void){
	return keyvalue;
}
void key_clear(void){
	keyvalue = 255;
}
void key_scan(void){
	static uint8_t keystatus = 0;
	
	switch(keystatus){
		case 0:
			if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_8) == GPIO_PIN_RESET || HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_8) == GPIO_PIN_RESET){
				keystatus = 1;
			}
			break;
		case 1:
			if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_8) == GPIO_PIN_RESET){
				keyvalue = 1; keystatus = 2;
			}else if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_8) == GPIO_PIN_RESET){
				keyvalue = 2; keystatus = 2;
			}else if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_8) == GPIO_PIN_RESET){
				keyvalue = 255; keystatus = 0;
			}
			break;
		case 2:
			if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_8) == GPIO_PIN_SET && HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_8) == GPIO_PIN_SET){
				keystatus = 0;
			}
			break;
	}
}

void task_key(void){
	
	if(key_ms == 10){
		key_ms = 0;
		key_scan();
	}
	
	if(key_return() == 1){
		
		HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_2);
		key_clear();
	}
	if(key_return() == 2){
		HAL_Delay(100);
		HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_5);
		HAL_Delay(100);
	}
	
}