#ifndef __TASK_H
#define __TASK_H
#include "gpio.h"
#include "stdio.h"


uint8_t key_return(void);
void key_clear(void);
void key_scan(void);
void task_key(void);
extern uint8_t key_ms;

#endif